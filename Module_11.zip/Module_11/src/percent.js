function getPercents(percent, number) {
    if (percent < 0) {
        return "Procent must be positive";
    } else if (percent > 100) {
        return "Procent can not be more than 100";
    } else {
        return number * percent / 100;
    }
}
module.exports = getPercents;


