const getPercents = require('./percent');

describe("test for getPercents function", () => {
    it("get 30 percents", () => {
        const result = getPercents(30, 200);
        expect(result).toBe(60);
    })
});

describe("another test for getPercents function", () => {
    it("get 60 percents", () => {
        const result = getPercents(60, 200);
        expect(result).toBe(120);
    }),
    it("get 90 percents", () => {
        const result = getPercents(90, 200);
        expect(result).toBe(180);
    })
});

describe("corner cases test for getPercents function", () => {
    it("test negative percents", () => {
        const result = getPercents(-45, 200);
        expect(result).toBe("Procent must be positive");
    }),
    it("test over 100 percents", () => {
        const result = getPercents(150, 200);
        expect(result).toBe("Procent can not be more than 100");
    })
});